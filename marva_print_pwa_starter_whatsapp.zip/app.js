const products = [
 {name:"کارت ویزیت",cat:"چاپ",symbol:"▤",desc:"چاپ کارت ویزیت در جنس‌ها و روکش‌های متنوع."},
 {name:"تراکت و بروشور",cat:"چاپ",symbol:"▧",desc:"مناسب معرفی خدمات، فروش ویژه و تبلیغات."},
 {name:"کاتالوگ و مجله",cat:"چاپ",symbol:"▥",desc:"چاپ چندصفحه‌ای برای معرفی حرفه‌ای محصولات."},
 {name:"سربرگ و پاکت",cat:"چاپ",symbol:"✉",desc:"اقلام اداری هماهنگ با هویت برند شما."},
 {name:"بنر و فلکس",cat:"تبلیغات محیطی",symbol:"▱",desc:"چاپ تبلیغات محیطی در ابعاد سفارشی."},
 {name:"استند تبلیغاتی",cat:"تبلیغات محیطی",symbol:"▤",desc:"راهکار نمایش محصول در فروشگاه و نمایشگاه."},
 {name:"پرچم ساحلی",cat:"پرچم",symbol:"⚑",desc:"پرچم تبلیغاتی با مدل‌ها و ابعاد مختلف."},
 {name:"پرچم رومیزی و تشریفاتی",cat:"پرچم",symbol:"⚑",desc:"مناسب دفتر، همایش، مراسم و رویدادها."},
 {name:"تابلو و استیکر",cat:"تبلیغات محیطی",symbol:"▣",desc:"راهکارهای بصری برای فروشگاه و فضای کار."},
 {name:"هدایای تبلیغاتی",cat:"تبلیغاتی",symbol:"♙",desc:"محصولات تبلیغاتی متناسب با برند شما."},
 {name:"طراحی لوگو و هویت بصری",cat:"طراحی",symbol:"✎",desc:"طراحی هویت بصری هماهنگ و کاربردی."},
 {name:"طراحی گرافیک تبلیغاتی",cat:"طراحی",symbol:"✧",desc:"طراحی فایل‌های تبلیغاتی برای چاپ و انتشار."}
];
let activeCategory="همه";
const grid=document.getElementById("productGrid");
const quoteProduct=document.getElementById("quoteProduct");
function renderProducts(){
 const q=(document.getElementById("searchInput").value||"").trim().toLowerCase();
 const list=products.filter(p=>(activeCategory==="همه"||p.cat===activeCategory)&&(!q||(p.name+" "+p.desc+" "+p.cat).toLowerCase().includes(q)));
 grid.innerHTML=list.length?list.map(p=>`<article class="product"><div class="product-art"><span class="symbol">${p.symbol}</span></div><span class="tag">${p.cat}</span><h3>${p.name}</h3><p>${p.desc}</p><div class="product-bottom"><span>قیمت: استعلامی</span><button type="button" data-quote="${p.name}">استعلام قیمت ↗</button></div></article>`).join(""):`<p class="empty">محصولی با این مشخصات پیدا نشد.</p>`;
 grid.querySelectorAll("[data-quote]").forEach(b=>b.addEventListener("click",()=>{quoteProduct.value=b.dataset.quote;document.getElementById("quote").scrollIntoView({behavior:"smooth"});}));
}
products.forEach(p=>quoteProduct.add(new Option(p.name,p.name)));
renderProducts();
document.getElementById("searchInput").addEventListener("input",renderProducts);
document.getElementById("filters").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(!b)return;activeCategory=b.dataset.category;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts();});
document.getElementById("menuToggle").addEventListener("click",()=>document.getElementById("nav").classList.toggle("open"));
document.querySelectorAll("#nav a").forEach(a=>a.addEventListener("click",()=>document.getElementById("nav").classList.remove("open")));
const toast=document.getElementById("toast");
function notify(msg){toast.textContent=msg;toast.classList.add("show");setTimeout(()=>toast.classList.remove("show"),3500);}
document.getElementById("quoteForm").addEventListener("submit",e=>{
 e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());
 // Replace this placeholder with the official WhatsApp number in international format, digits only.
 const WHATSAPP_NUMBER="989100390709";
 const msg=`درخواست استعلام قیمت - گروه چاپ مروا\nنام: ${d.name}\nتلفن: ${d.phone}\nمحصول: ${d.product}\nتعداد: ${d.quantity||"ذکر نشده"}\nابعاد/مشخصات: ${d.specs||"ذکر نشده"}\nتوضیحات: ${d.details||"ندارد"}\nلینک فایل: ${d.filelink||"ندارد"}`;
 if(!WHATSAPP_NUMBER){notify("شماره واتساپ هنوز تنظیم نشده است.");return;}
 window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`,"_blank","noopener");
});
if("serviceWorker" in navigator && location.protocol!=="file:"){window.addEventListener("load",()=>navigator.serviceWorker.register("./service-worker.js").catch(()=>{}));}
